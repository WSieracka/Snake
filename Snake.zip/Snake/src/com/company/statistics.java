package com.company;

import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.util.Objects;

/**
 * Creates an interface to the statistics window and writes the high score to a file and reads the previous high score from the file.
 */
public class statistics {
    private String hightscore=" ";

    /**
     * Checks if the record is broken, if so, writes it to a file.
     * @return hightscore - the best result
     */
    public String HScore(int score){
        if (hightscore.equals(" ")){
            hightscore = this.GetHightscore();
        }
        if(score > Integer.parseInt((hightscore.split(" has highest score: ")[1]))){
            String name = JOptionPane.showInputDialog("What is your name?");
            hightscore =name + " has highest score: " + score;
            File score_file = new File("hightscore.dat");
            if(!score_file.exists()){
                try{
                    score_file.createNewFile();
                }catch(IOException e){
                    e.printStackTrace();
                }
            }
            FileWriter write = null;
            BufferedWriter writer = null;
            try{
                write = new FileWriter(score_file);
                writer = new BufferedWriter(write);
                writer.write(this.hightscore);


            }catch(IOException e){
                e.printStackTrace();
            }
            finally{
                try{
                    if(writer != null){
                        writer.close();
                    }
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
            }

        }
        return hightscore;
    }


    /**
     *The function reads the best result from the file
     */
    public String GetHightscore(){
        BufferedReader reader = null;
        FileReader file = null;
        try{
            file = new FileReader("hightscore.dat");
            reader = new BufferedReader(file);
            return reader.readLine();
        }
        catch(Exception e){
            return "NN:0";
        }
        finally{
            try{
                if(reader != null){
                    reader.close();
                }
            }catch(IOException e){
                e.printStackTrace();
            }

        }

    }

    /**
     * Creates an interface to the statistics window.
     */
    public JPanel Paint(){
        JPanel panel = new JPanel();

        LayoutManager overlay = new OverlayLayout(panel);
        panel.setLayout(overlay);
        String napis = this.GetHightscore();
        JLabel label1 = new JLabel(napis);
        label1.setForeground(Color.RED);
        label1.setFont(new Font("SansSerif", Font.BOLD, 16));
        label1.setAlignmentX(0.5f);
        label1.setAlignmentY(0.5f);
        panel.add(label1);
        JLabel label2 = new JLabel(new ImageIcon(Objects.requireNonNull(this.getClass().getResource("resources/images/sta.png"))));
        label2.setAlignmentX(0.5f);
        label2.setAlignmentY(0.5f);
        panel.add(label2);

        return panel;
    }


}
