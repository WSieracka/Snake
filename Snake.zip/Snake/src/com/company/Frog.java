package com.company;

import java.awt.*;
import java.util.List;

/**
 * Class to manage Frog
 */
public class Frog extends Apple
{
    /**
     * Constructor
     */
    public Frog()
    {
        loadImage("src/resources/images/frog.png");
    }

    /**
     * Function to move frog right
     */
    private void move_right() { position_X += 10; }

    /**
     * Function to move frog left
     */
    private void move_left() { position_X -= 10; }

    /**
     * Function to move frog up
     */
    private void move_up() { position_Y -= 10; }

    /**
     * Function to move frog down
     */
    private void move_down() { position_Y += 10; }

    /**
     * Function to appear frog randomly
     * @param objects_list List of all objects
     */
    @Override
    public void place_random(List<Objects> objects_list)
    {
        position_Y = random_int(16, 55);
        position_X = random_int(16, 55);

        while(spawnpoint_check(objects_list))
        {
            position_Y = random_int(25, 54);
            position_X = random_int(25, 54);
        }
    }

    /**
     * Function to make task run
     * @param snake position of Snake to run from
     */
    public Runnable createRunnable(Rectangle snake)
    {
        Runnable tempRunnable = new Runnable() {
            @Override
            public void run() {
                move(snake);
            }
        };
        return tempRunnable;
    }

    /**
     * Function to make frog move
     * @param snake_position position of snake to run from
     */
    public void move(Rectangle snake_position)
    {
        int run_decision = random_int(0,2) / 10;
        if(run_decision % 2 == 1)
            return;

        int random_number = random_int(0, 3) / 10;
        chaseFromDown(snake_position, random_number);
        chaseFromUp(snake_position, random_number);
    }

    /**
     * Function to randomly choose direction to run if snake is up
     * @param snake_position position of snake to run from
     * @param random_number random number to select where to go
     */
    private void chaseFromUp(Rectangle snake_position, int random_number)
    {
        if(snake_position.intersects(position_X -150, position_Y -150, 300, 150))
        {
            if(random_number <= 1)
                move_down();
            else if(random_number == 2)
                move_right();
            else if(random_number == 3)
                move_left();
        }
    }

    /**
     * Function to randomly choose direction to run if snake is down
     * @param snake_position position of snake to run from
     * @param random_number random number to select where to go
     */
    private void chaseFromDown(Rectangle snake_position, int random_number)
    {
        if(snake_position.intersects(position_X -150, position_Y, 300, 150))
        {
            if(random_number <= 1)
                move_up();
            else if(random_number == 2)
                move_right();
            else if(random_number == 3)
                move_left();
        }
    }

}
