package com.company;

import java.awt.*;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import javax.swing.*;

/**
 * CLass that holds actual snake game and score table
 */
public class Game_Panel extends JPanel {

    private final GridBagConstraints gbc;
    private final ScoreTable score_table;
    private final Snake_game snake_game;

    /**
     * Constructor
     * creates score table, snake game
     */
    public Game_Panel()
    {
        score_table = new ScoreTable();
        snake_game = new Snake_game();
        gbc = new GridBagConstraints();
        snake_game.create_snake_change_listener(new PropertyChangeListener() {
            @Override
            public void propertyChange(PropertyChangeEvent evt)
            {
                score_table.get_score().setText(String.valueOf(snake_game.get_score()));
            }
        });
        setLayout(new GridBagLayout());
        create_score();
        create_snake_game();
    }

    /**
     * Creates score table
     */
    private void create_score()
    {
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.weightx = 1.0;
        gbc.ipady = Constants.SCORE_TABLE_HEIGHT;
        gbc.anchor = GridBagConstraints.NORTHWEST;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        add(score_table, gbc);
    }

    /**
     * Creates actual snake game
     */
    private void create_snake_game()
    {
        gbc.gridy = 1;
        gbc.weighty = 1.0;
        gbc.ipady = 0;
        gbc.fill = GridBagConstraints.BOTH;
        add(snake_game, gbc);

    }

}