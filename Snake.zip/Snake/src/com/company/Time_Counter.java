package com.company;

import javax.swing.*;
import java.awt.*;
import java.util.concurrent.TimeUnit;

/**
 * CLass to manage time counting
 */
public class Time_Counter extends JLabel
{
    static Timer timer;
    static long time;

    /**
     * Constructor
     */
    public Time_Counter()
    {
        timer = new Timer(1000, e -> setText(String.format("%02d:%02d",
                TimeUnit.MILLISECONDS.toMinutes(System.currentTimeMillis() - time),
                TimeUnit.MILLISECONDS.toSeconds(System.currentTimeMillis() - time) -
                        TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(System.currentTimeMillis() - time)
                ))));
        setText("00:00");
        setFont(new Font("Verdana", Font.BOLD, 40));
        setForeground(Color.white);
    }

    /**
     * Function to start counting
     */
    public static void start_counter()
    {
        time = System.currentTimeMillis();
        timer.start();
    }

}
