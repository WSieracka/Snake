package com.company;

import javax.swing.*;
import java.awt.*;
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;

/**
 * Class of object snake
 */
public class Snake implements Runnable
{
    private int length;
    private Image body;
    private Image head;
    private final int[] x = new int[Constants.WIDTH];
    private final int[] y = new int[Constants.HEIGHT];
    private final Key_Adapter key_adapter = new Key_Adapter();
    private final PropertyChangeSupport change_supp;

    /**
     * Constructor
     */
    public Snake()
    {
        change_supp = new PropertyChangeSupport(this);
        length = Constants.START_SNAKE_LENGTH;
        for (int z = 0; z < length; z++)
        {
            x[z] = 50 - z * Constants.BASIC_LENGTH;
            y[z] = 50;
        }
        ImageIcon temp_body = new ImageIcon("src/resources/images/snake_body.png");
        body = temp_body.getImage();

        ImageIcon temp_head = new ImageIcon("src/resources/images/snake_head.png");
        head = temp_head.getImage();
    }

    /**
     * Return key adapter of event
     * @return key adapter of event
     */
    public Key_Adapter get_event_adapt() { return key_adapter; }

    /**
     * Returns position and dimensions of snake
     * @return position in X of head, position in Y of head, width and height of snake
     */
    public Rectangle get_position()
    {
        return new Rectangle(get_head_X(), get_head_Y(), 10, 10);
    }

    /**
     * Return snake's head position in X
     * @return int of snake's head position in X
     */
    public int get_head_X() { return x[0]; }
    /**
     * Return snake's head position in Y
     * @return int of snake's head position in Y
     */
    public int get_head_Y() { return y[0]; }
    /**
     * Return snake's length
     * @return int of snake's length
     */
    public int get_length() { return length; }

    /**
     * Set length of snake to given value
     * @param length to which length of snake should be set
     */
    public void set_length(int length)
    {
        int old_length = this.length;
        this.length = length;
        change_supp.firePropertyChange("dotLength", old_length, this.length);
    }

    /**
     * Function to make snake move all the time during game
     */
    @Override
    public void run() {
        for (int z = length; z > 0; z--)
        {
            x[z] = x[(z - 1)];
            y[z] = y[(z - 1)];
        }

        if (key_adapter.get_left())  { x[0] -= Constants.BASIC_LENGTH; }
        if (key_adapter.get_right()) { x[0] += Constants.BASIC_LENGTH; }
        if (key_adapter.get_up())    { y[0] -= Constants.BASIC_LENGTH; }
        if (key_adapter.get_down())  { y[0] += Constants.BASIC_LENGTH; }
    }

    /**
     * Checks if snake hit the border of board
     * @return true if snake hit the border, false if snake didnt hit
     */
    public boolean check_collision_border()
    {
        for (int z = length; z > 0; z--)
        {
            if ((z > 4) && (get_head_X() == x[z]) && (get_head_Y() == y[z]))
                return false;
        }

        if (get_head_Y() >= Constants.HEIGHT - Constants.SCORE_TABLE_HEIGHT) { return false; }
        if (get_head_Y() < 0) { return false; }
        if (get_head_X() >= Constants.WIDTH) { return false; }
        return get_head_X() >= 0;
    }

    /**
     * Draws snake
     * @param graphics to draw
     * @param board is snake game board
     */
    public void draw(Graphics graphics, Snake_game board)
    {
        graphics.drawImage(head, get_head_X(), get_head_Y(), board);
        for (int z = 1; z< length; z++)
            graphics.drawImage(body, x[z], y[z], board);
    }

    /**
     * Adds listener to property changes in snake
     * @param listener to add to snake
     */
    public void create_change_listener(PropertyChangeListener listener)
    {
        change_supp.addPropertyChangeListener(listener);
    }
}
