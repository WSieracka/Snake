package com.company;

/**
 * Class for creating and managing obstacles
 */
public class Obstacle extends Objects
{
    private static int counter;

    /**
     * Constructor of Obstacle
     */
    public Obstacle()
    {
        ++counter;
        loadImage("src/resources/images/obstacle.png");
        width = image.getWidth(null);
        height = image.getHeight(null);
        place_random();
    }

    /**
     * Function to generate random place to put obstacle
     */
    private void place_random()
    {
        position_Y = random_int(5, 30);
        if(counter % 2 == 0)
            position_X = random_int(5, 35);
        else
            position_X = random_int(45, 70);
    }
}
