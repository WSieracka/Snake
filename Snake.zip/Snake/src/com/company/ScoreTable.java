package com.company;

import javax.swing.*;
import java.awt.*;

/**
 * Graphic element that shows score
 */
public class ScoreTable extends JPanel
{
    private final JLabel score;

    /**
     * Constructor of ScoreTable
     */
    public ScoreTable()
    {
        Time_Counter time_count = new Time_Counter();
        setBackground(new Color(50, 100, 150));
        setLayout(null);
        score = new JLabel("0");
        score.setBounds(100, 13, 80 ,50 );
        score.setFont(new Font("Verdana", Font.BOLD, 40));
        score.setForeground(Color.white);
        add(score);

        time_count.setBounds(400, 13, 150 ,50);
        add(time_count);
    }

    /**
     * Function that returns score
     * @return score
     */
    public JLabel get_score() { return score; }
}

