package com.company;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.beans.PropertyChangeListener;

/**
 * Class that manages whole snake game window (actual gameplay)
 */
public class Snake_game extends JPanel implements ActionListener
{
    private final Map map;
    private final Snake snake;
    private final Apple apple;
    private final Frog frog;
    private final Threads poolThreads;
    private final Timer timer;
    private boolean inGame;

    /**
     * Constructor of snake game
     * creates map, snake, fruit, frog
     */
    public Snake_game()
    {
        map = new Map();
        snake = new Snake();
        apple = new Apple();
        frog = new Frog();
        timer = new Timer(Constants.DELAY, this);
        poolThreads = new Threads(4);
        setFocusable(true);
        setBackground(Color.black);
        setLayout(null);
        addKeyListener(snake.get_event_adapt());
        apple.place_random(map.get_objects());
        frog.place_random(map.get_objects());
        timer.start();
        Time_Counter.start_counter();
        inGame = true;

    }

    /**
     * Checks if snake hit anything
     * If he hit, changes inGame variable to false so game over will be called
     */
    public void collision_check()
    {
        Rectangle snake = this.snake.get_position();
        for(Objects obj : map.get_objects())
        {
            Rectangle object = obj.get_position();
            if(snake.intersects(object))
                inGame = false;
        }
    }

    /**
     * Calls all function that should be called after action was performed
     * Checks if snake hit anything or can eat something
     * @param e action
     */
    @Override
    public void actionPerformed(ActionEvent e)
    {
        if (inGame)
        {
            apple.eating_check(snake, map.get_objects());
            frog.eating_check(snake, map.get_objects());
            poolThreads.run_task(frog.createRunnable(snake.get_position()));
            poolThreads.run_task(snake);
            inGame = snake.check_collision_border();
            this.collision_check();
            if (!inGame)
            {
                timer.stop();
                menu.game_over(get_score());
            }
        }
        repaint();
    }

    /**
     * Paints object
     * @param graphics to paint
     */
    @Override
    public void paintComponent(Graphics graphics)
    {
        super.paintComponent(graphics);
        draw_objects(graphics);
    }

    /**
     * Function to draw all objects in snake game
     * @param graphics to draw
     */
    private void draw_objects(Graphics graphics)
    {
        if (inGame)
        {
            map.map_draw(graphics, this);
            apple.draw(graphics, this);
            frog.draw(graphics, this);
            snake.draw(graphics,this);
            Toolkit.getDefaultToolkit().sync();
        }
    }

    /**
     * Returns score
     * @return int that is actual length of snake minus starting length which equals score
     */
    public int get_score()
    {
        return snake.get_length() - Constants.START_SNAKE_LENGTH;
    }

    /**
     * Creates listener of property changes in snake
     * @param listener to create
     */
    public void create_snake_change_listener(PropertyChangeListener listener)
    {
        snake.create_change_listener(listener);
    }


}
