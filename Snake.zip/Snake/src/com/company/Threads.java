package com.company;

import java.util.LinkedList;
import java.util.List;

/**
 * Class to manage threads
 */
public class Threads extends ThreadGroup
{
    private final List<Runnable> tasks;
    private final int threads_count;
    private final boolean running;

    /**
     * Constructor
     * @param threads_counter counter of threads to set
     */
    public Threads(int threads_counter)
    {
        super("ThreadPool");
        this.threads_count = threads_counter;
        this.running = true;
        this.tasks = new LinkedList<>();
        threads_create();
    }

    /**
     * Creates threads
     */
    private void threads_create()
    {
        for(int i = 0; i<this.threads_count; ++i)
            new Threads_pool(this).start();
    }

    /**
     * Returns task
     * @return task
     */
    protected synchronized Runnable get_task() throws InterruptedException
    {
        while (this.tasks.size() == 0)
        {
            if(!this.running) return null;
            wait();
        }
        return this.tasks.remove(0);
    }

    /**
     * Ads task to list of running tasks
     * @param task task to run
     */
    public synchronized void run_task(Runnable task)
    {
        if(task != null)
        {
            tasks.add(task);
            notify();
        }
    }

}
