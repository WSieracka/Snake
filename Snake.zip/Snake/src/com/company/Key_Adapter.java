package com.company;

import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

/**
 * Function that manages communication with user
 * User uses keyboard arrows to move snake
 */
public class Key_Adapter extends KeyAdapter {

    private boolean dir_right = true;
    private boolean dir_left = false;
    private boolean dir_down = false;
    private boolean dir_up = false;

    /**
     * Checks which key was pressed and changes direction of snake
     * @param event which key was pressed
     */
    public void keyPressed(KeyEvent event)
    {

        int key = event.getKeyCode();
        if ((key == KeyEvent.VK_LEFT) && (!dir_right))
        {
            dir_left = true;
            dir_up = false;
            dir_down = false;
        }

        if ((key == KeyEvent.VK_UP) && (!dir_down))
        {
            dir_right = false;
            dir_left = false;
            dir_up = true;
        }

        if ((key == KeyEvent.VK_RIGHT) && (!dir_left))
        {
            dir_right = true;
            dir_up = false;
            dir_down = false;
        }

        if ((key == KeyEvent.VK_DOWN) && (!dir_up))
        {
            dir_right = false;
            dir_left = false;
            dir_down = true;
        }
    }

    /**
     * Returns true if snake is moving right
     * @return boolean (value) of dir_right
     */
    public boolean get_right() { return dir_right; }

    /**
     * Returns true if snake is moving left
     * @return boolean (value) of dir_left
     */
    public boolean get_left() { return dir_left; }

    /**
     * Returns true if snake is moving up
     * @return boolean (value) of dir_up
     */
    public boolean get_up() { return dir_up; }

    /**
     * Returns true if snake is moving down
     * @return boolean (value) of dir_down
     */
    public boolean get_down() { return dir_down; }
}