package com.company;

import javax.swing.*;
import java.awt.*;

/**
 * Class to manage objects
 */
public class Objects
{
    protected int position_X;
    protected int position_Y;
    protected int width = Constants.BASIC_LENGTH;
    protected int height = Constants.BASIC_LENGTH;
    protected Image image;

    /**
     * Constructor
     */
    public Objects() { }

    /**
     * Returns position in X of object
     * @return int position in X
     */
    public int get_X() { return position_X; }

    /**
     * Returns position in Y of object
     * @return int position in Y
     */
    public int get_Y() { return position_Y; }

    /**
     * Gives position and dimensions of object
     * @return ints that are position in X, position in Y, width and height
     */
    public Rectangle get_position()
    {
        return new Rectangle(position_X, position_Y, width, height);
    }

    /**
     * Loads image of an object
     * @param file_name name of file of image of an object
     */
    protected void loadImage(String file_name)
    {
        ImageIcon temp_image = new ImageIcon(file_name);
        image = temp_image.getImage();
    }

    /**
     * Draw object
     * @param graphics used to draw
     * @param sn_game snake game board where object should be painted
     */
    public void draw(Graphics graphics, Snake_game sn_game)
    {
        graphics.drawImage(image, get_X(), get_Y(), sn_game);
    }

    /**
     * Creates random number beetwen two numbers
     * @param min Minimum number
     * @param maxi Maximum number
     * @return random int number
     */
    protected int random_int(int min, int maxi)
    {
        return (min + (int) (Math.random() * ((maxi - min) + 1))) * 10;
    }

}
