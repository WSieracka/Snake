package com.company;

/**
 * Used to store and manage Ids that are given to threads
 */
public class Thread_Id
{
    private int ID_counter;

    /**
     * Set Index counter to given value
     * @param ID_counter counter of thread index
     */
    public Thread_Id(int ID_counter)
    {
        this.ID_counter = ID_counter;
    }

    /**
     * Gives index for new thread
     * @return index for new thread
     */
    public int next()
    {
        return ID_counter++;
    }

}
