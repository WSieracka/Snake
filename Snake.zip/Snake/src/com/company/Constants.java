package com.company;

/**
 * Contains all constant values used in project
 */
public final class Constants
{
    private Constants() { }

    public static final int HEIGHT = 800;
    public static final int WIDTH = 800;
    public static final int BASIC_LENGTH = 10;
    public static final int START_SNAKE_LENGTH = 3;
    public static final int DELAY = 100;
    public static final int SCORE_TABLE_HEIGHT = (((HEIGHT / 11) + 5) / 10) * 10;
}