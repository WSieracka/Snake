package com.company;

import java.awt.*;
import java.util.List;

/**
 * Class to manage Apple
 */
public class Apple extends Objects
{
    /**
     * Constructor
     */
    public Apple()
    {
        loadImage("src/resources/images/apple.png");
    }

    /**
     * Checks if apple appeared in obstacle
     * @param objects list of all objects
     * @return returns false if it's not in obstacle list
     */
    protected boolean spawnpoint_check(List<Objects> objects)
    {
        for (Objects obj : objects)
        {
            Rectangle object_pos = obj.get_position();
            if (object_pos.intersects(this.get_position()))
                return true;
        }
        return false;
    }

    /**
     * Function to appear apple randomly
     * @param objects_list List of all objects
     */
    public void place_random(List<Objects> objects_list)
    {
        position_Y = random_int(0, 71);
        position_X = random_int(0, 71);

        while(spawnpoint_check(objects_list))
        {
            position_Y = random_int(0, 71);
            position_X = random_int(0, 71);
        }
    }

    /**
     * Function to check if snake can eat apple, if so, he gets longer and new apple appears
     * @param snake Snake for which we check if it can eat
     * @param objects_list List of all objects
     */
    public void eating_check(Snake snake, List<Objects> objects_list)
    {
        if ((snake.get_head_X() == this.get_X()) && (snake.get_head_Y() == this.get_Y()))
        {
            snake.set_length(snake.get_length() + 1);
            this.place_random(objects_list);
        }
    }
}
