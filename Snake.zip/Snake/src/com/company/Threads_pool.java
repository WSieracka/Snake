package com.company;

/**
 * Class to manage threads
 */
public class Threads_pool extends Thread
{
    private static final Thread_Id threadID = new Thread_Id(1);
    private final Threads pool;

    /**
     * Constructor
     * @param pool where thread belongs
     */
    public Threads_pool(Threads pool)
    {
        super(pool, "PooledThread-" + threadID.next());
        this.pool = pool;
    }

    /**
     * Function to run thread
     */
    @Override
    public void run()
    {
        while (!isInterrupted())
        {
            Runnable task = null;
            try {
                task = pool.get_task();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            if(task == null)
                return;

            try {
                task.run();
            }
            catch (Throwable t) {
                pool.uncaughtException(this, t);
            }
        }
    }
}
