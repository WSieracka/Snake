package com.company;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Class to hold list of all objects
 */
public class Map
{
    private final List<Objects> objects;

    /**
     * Constructor (creates 2 random obstacles)
     */
    public Map()
    {
        objects = new ArrayList<>();
        Objects obst = new Obstacle();
        objects.add(obst);
        for(int i=0; i<1; ++i)
        {
            obst = new Obstacle();
            objects.add(obst);
        }
    }

    /**
     * Draws all objects in map
     * @param graphics to draw
     * @param board snake game board where objects are
     */
    public void map_draw(Graphics graphics, Snake_game board)
    {
        for(Objects obj : objects)
            obj.draw(graphics, board);
    }

    /**
     * Returns list of objects
     * @return list of objects
     */
    public List<Objects> get_objects()
    {
        return objects;
    }
}
